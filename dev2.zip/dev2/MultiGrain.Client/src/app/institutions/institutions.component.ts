import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-institutions',
  templateUrl: './institutions.component.html',
  styles: []
})
export class InstitutionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
