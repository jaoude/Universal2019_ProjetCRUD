import {NgModule} from '@angular/core';
import { Routes, RouterModule}
from '@angular/router';
import {PaymentDetailsComponent} from './payment-details/payment-details.component';
import { InstitutionsComponent } from './Institutions/institutions.component'
const routes : Routes = [
  { path: 'students', component: PaymentDetailsComponent },
  { path: 'Institutions', component: InstitutionsComponent }
];

@NgModule ({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule{}
export const routingComponent = [PaymentDetailsComponent, InstitutionsComponent]