export class Institution {
    Id :number;
    LectureDuration: number;
    mission: string;
    signature: string;
    title: string;
    vision: string;
}
