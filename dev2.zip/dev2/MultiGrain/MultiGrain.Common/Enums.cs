﻿using System;

namespace MultiGrain.Common
{
    public static class Enums
    {
        public enum EvaluationType
        {
            None = 0,
            Exams = 1,
            Project = 2,
            Thesis = 4
        }
    }
}
