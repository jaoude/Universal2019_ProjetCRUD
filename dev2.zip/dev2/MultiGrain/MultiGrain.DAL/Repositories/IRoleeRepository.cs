﻿using MultiGrain.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MultiGrain.DAL.Repositories
{
    public interface IRoleeRepository : IRepository<Rolee>
    {

    }
}
