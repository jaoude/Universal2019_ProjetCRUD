﻿using MultiGrain.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace MultiGrain.DAL.Repositories
{
    public interface IKPIRepository : IRepository<KPI>
    {

    }
}
