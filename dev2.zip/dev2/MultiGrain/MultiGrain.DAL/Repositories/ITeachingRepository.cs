﻿using MultiGrain.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MultiGrain.DAL.Repositories
{
    public interface ITeachingRepository : IRepository<Teaching>
    {
    }
}
